<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sidebar Admin</title>
</head>
<body>
    <div class="sidebar-admin">
        <a href="index.php">Dashboard</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/pengguna/">Data Pengguna</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/maskapai/">Data Maskapai</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/kota/">Data Kota</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/rute/">Data Rute</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/jadwal/">Data Jadwal Penerbangan</a>&nbsp;&nbsp;
        <a href="/e-ticketing/admin/order/">Pemesanan Tiket</a>&nbsp;&nbsp;
        <a href="../../logout.php" onClick="return confirm('Apakah anda yakin ingin logout?')">Logout</a>
    </div>
</body>
</html>